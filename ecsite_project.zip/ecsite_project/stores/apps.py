from django.apps import AppConfig


class StoresConfig(AppConfig):
    name = 'stores'
